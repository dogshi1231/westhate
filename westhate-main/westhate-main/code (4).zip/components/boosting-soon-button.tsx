"use client"

import { useState } from "react"

export function BoostingSoonButton() {
  const [show, setShow] = useState(false)

  return (
    <div className="relative">
      <button
        onClick={() => setShow((prev) => !prev)}
        onMouseEnter={() => setShow(true)}
        onMouseLeave={() => setShow(false)}
        className="text-white/60 hover:text-white transition-colors duration-300 py-2 relative whitespace-nowrap font-extrabold leading-7 text-lg lg:text-xl group"
      >
        Boosting
        <span
          className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0.5 bg-gradient-to-r from-red-500 to-purple-500 group-hover:w-full transition-all duration-300 ease-out"
          style={{
            boxShadow: "0 0 8px rgba(239, 68, 68, 0.8), 0 0 12px rgba(239, 68, 68, 0.5)",
          }}
        />
      </button>

      <div
        className={`
          absolute top-full mt-2 left-1/2 -translate-x-1/2 z-50
          px-3 py-2 rounded-lg text-xs font-semibold whitespace-nowrap
          bg-black border border-white/20 text-white/90
          transition-all duration-200 ease-out pointer-events-none
          ${show ? "opacity-100 scale-100" : "opacity-0 scale-95"}
        `}
        style={{
          boxShadow: "0 4px 20px rgba(0, 0, 0, 0.8), 0 0 15px rgba(239, 68, 68, 0.3)",
        }}
      >
        Coming Soon
      </div>
    </div>
  )
}
