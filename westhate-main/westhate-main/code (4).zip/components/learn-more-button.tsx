import type React from "react"
import { Info } from "lucide-react"

/**
 * Larger HWIDR-style translucent "Learn More" button
 * Matches the 178×94px visual scale (32px vertical padding, 40px horizontal)
 * with 18px Geist-like text.
 */
export function LearnMoreButton({
  children = "Learn More",
  icon = true,
  className = "",
}: {
  children?: React.ReactNode
  icon?: boolean
  className?: string
}) {
  return (
    <button
      className={`btn-ghost-panel inline-flex items-center justify-center gap-2 whitespace-nowrap transition-all
                  text-[18px] font-medium px-10 py-8 rounded-xl ${className}`}
      style={{
        fontFamily: '"Geist", "Geist Fallback", sans-serif',
        padding: "32px 40px", // matches your inspector screenshot
      }}
    >
      {icon && <Info className="w-5 h-5 mr-2 opacity-90" strokeWidth={2} />}
      {children}
    </button>
  )
}
