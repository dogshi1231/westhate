"use client"

import { useEffect, useRef } from "react"

/**
 * This component recreates the Site A background behavior:
 * - full-screen black canvas
 * - dot grid that reacts to cursor position
 * - click waves that radiate out and colorize dots temporarily
 *
 * IMPORTANT:
 * - We keep the canvas full-screen, fixed, behind everything (-z-index via layout/css).
 * - We listen for mousemove / touchmove / click on window, not on the canvas only,
 *   so the foreground UI is still clickable.
 */
export function AnimatedBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // --- CONFIG / STATE (mirrors script.js logic from Site A) ---
    let width = 0
    let height = 0
    const dpr = Math.min(2, Math.max(1, window.devicePixelRatio || 1))

    let mouseX = -9999
    let mouseY = -9999
    let displayX = -9999
    let displayY = -9999
    let hasPointer = false

    // waves = expanding rings from click
    type Wave = {
      x: number
      y: number
      radius: number
      maxRadius: number
      speed: number
      opacity: number
      color: string
      thickness: number
      life: number
      maxLife: number
      intensity: number
      frequency: number
    }
    const waves: Wave[] = []
    let lastClickTime = 0
    let waveId = 0

    // Performance tracking (script.js used this for frame skipping on low FPS)
    let lastFrameTime = 0
    let frameCount = 0
    let fps = 60
    let isLowPerf = false
    let skipFrames = 0

    // Dot field config (taken from your current AnimatedBackground.tsx
    // + Site A's defaults: spacing, radius, influence, etc.)
    const baseSpacing = 15
    const baseRadius = 0.75
    const influence = 150
    const growth = 2
    const follow = 0.6
    const colorThreshold = 0.3

    const palette = ["#FFFFFF", "#F5F5F5", "#E8E8E8", "#D3D3D3", "#C0C0C0", "#A9A9A9"]
    const colorCount = palette.length
    let shimmerTime = 0

    // Resize logic like Site A initInteractiveDots()
    function resize() {
      width = window.innerWidth
      height = window.innerHeight
      canvas.width = Math.floor(width * dpr)
      canvas.height = Math.floor(height * dpr)
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    }
    resize()
    let resizeTimer: ReturnType<typeof setTimeout> | null = null
    const handleResize = () => {
      if (resizeTimer) clearTimeout(resizeTimer)
      resizeTimer = setTimeout(resize, 120)
    }
    window.addEventListener("resize", handleResize)

    // Pointer tracking
    function onMove(e: { clientX: number; clientY: number }) {
      mouseX = e.clientX
      mouseY = e.clientY
      if (!hasPointer) {
        displayX = mouseX
        displayY = mouseY
        hasPointer = true
      }
    }

    // Make sure animation loop is running whenever there's movement / waves
    let isAnimating = false
    function ensureAnimating() {
      if (!isAnimating) {
        isAnimating = true
        requestAnimationFrame(draw)
      }
    }

    // Attach listeners for movement
    const handleMouseMove = (e: MouseEvent) => {
      onMove(e)
      ensureAnimating()
    }
    const handleTouchMove = (e: TouchEvent) => {
      if (!e.touches || !e.touches[0]) return
      mouseX = e.touches[0].clientX
      mouseY = e.touches[0].clientY
      if (!hasPointer) {
        displayX = mouseX
        displayY = mouseY
        hasPointer = true
      }
      ensureAnimating()
    }
    window.addEventListener("mousemove", handleMouseMove, { passive: true })
    window.addEventListener("touchmove", handleTouchMove, { passive: true })

    // Wave creation (click ripple)
    function createWave(x: number, y: number) {
      const now = performance.now()
      if (now - lastClickTime < 200) return // don't spam waves too fast
      lastClickTime = now

      const randomColor = palette[Math.floor(Math.random() * palette.length)]

      const wave: Wave = {
        x,
        y,
        radius: 0,
        maxRadius: Math.max(width, height) * 1.5,
        speed: 3 + Math.random() * 2, // ~3-5 px/frame
        opacity: 1,
        color: randomColor,
        thickness: 2 + Math.random() * 2,
        life: 0,
        maxLife: 150, // ~2.5s @ 60fps
        intensity: 0.6 + Math.random() * 0.4,
        frequency: 0.05 + Math.random() * 0.1,
      }

      waveId++
      waves.push(wave)
      ensureAnimating()
    }

    const handleClick = (e: MouseEvent) => {
      createWave(e.clientX, e.clientY)
    }
    const handleTouchStart = (e: TouchEvent) => {
      if (!e.touches || !e.touches[0]) return
      createWave(e.touches[0].clientX, e.touches[0].clientY)
    }

    window.addEventListener("click", handleClick, { passive: true })
    window.addEventListener("touchstart", handleTouchStart, { passive: true })

    // The main draw loop (merged logic from Site A script.js and your current component)
    function draw(currentTime: number) {
      const deltaTime = currentTime - lastFrameTime
      lastFrameTime = currentTime

      // Performance throttle like Site A
      skipFrames++
      frameCount++
      if (frameCount % 30 === 0 && deltaTime > 0) {
        fps = 1000 / deltaTime
        isLowPerf = fps < 35
      }
      if (isLowPerf && fps < 25 && skipFrames % 3 !== 0) {
        // super low FPS? skip render some frames
        requestAnimationFrame(draw)
        return
      }

      // Smooth cursor follow
      if (hasPointer) {
        displayX += (mouseX - displayX) * follow
        displayY += (mouseY - displayY) * follow
      }

      shimmerTime += deltaTime * 0.003

      ctx.fillStyle = "#000000"
      ctx.fillRect(0, 0, width, height)

      // Update waves (expand, fade)
      for (let i = waves.length - 1; i >= 0; i--) {
        const w = waves[i]
        w.radius += w.speed
        w.life++
        w.opacity = Math.max(0, 1 - w.life / w.maxLife)
        if (w.opacity <= 0 || w.radius > w.maxRadius) {
          waves.splice(i, 1)
        }
      }

      // Build dot lists to draw (white vs colored)
      const whiteDots: Array<{ x: number; y: number; r: number }> = []
      const coloredDots: Array<{ x: number; y: number; r: number; baseColor: string }> = []

      const centerX = hasPointer ? displayX : width * 0.5
      const centerY = hasPointer ? displayY : height * 0.35

      for (let gy = -baseSpacing; gy < height + baseSpacing; gy += baseSpacing) {
        for (let gx = -baseSpacing; gx < width + baseSpacing; gx += baseSpacing) {
          const dx = gx - centerX
          const dy = gy - centerY
          const dist = Math.sqrt(dx * dx + dy * dy)

          // how "influenced" this dot is by the cursor blob
          const t = Math.max(0, 1 - dist / influence)
          const baseR = baseRadius + growth * t

          // wave overlay logic (ripple color band)
          let waveInfluence = 0
          let waveColor: string | null = null
          if (waves.length > 0) {
            for (const w of waves) {
              const waveDist = Math.sqrt((gx - w.x) ** 2 + (gy - w.y) ** 2)
              // dot is "inside" the wave ring if it's near wave.radius
              if (waveDist <= w.radius && waveDist >= w.radius - 40) {
                const waveEffect = w.intensity * (1 - Math.abs(waveDist - w.radius) / 40)
                if (waveEffect > waveInfluence) {
                  waveInfluence = waveEffect
                  waveColor = w.color
                }
              }
            }
          }

          // Decide if dot is white or colored
          if (t > colorThreshold || waveInfluence > 0.3) {
            // determine base color
            let baseColor: string
            if (waveInfluence > 0.3 && waveColor) {
              baseColor = waveColor
            } else {
              const shimmerPhase = Math.sin(gx * 0.03 + gy * 0.03 + shimmerTime * 0.8) * 0.5 + 0.5
              const colorIndex = Math.floor(shimmerPhase * colorCount) % colorCount
              baseColor = palette[colorIndex]
            }

            const finalR = baseR + waveInfluence * 2.5
            coloredDots.push({ x: gx, y: gy, r: finalR, baseColor })
          } else {
            whiteDots.push({ x: gx, y: gy, r: baseR })
          }
        }
      }

      // Draw white dots as one path for performance
      if (whiteDots.length > 0) {
        ctx.fillStyle = "#ffffff"
        ctx.beginPath()
        for (let i = 0; i < whiteDots.length; i++) {
          const dot = whiteDots[i]
          ctx.moveTo(dot.x + dot.r, dot.y)
          ctx.arc(dot.x, dot.y, dot.r, 0, Math.PI * 2)
        }
        ctx.fill()
      }

      // Draw colored dots individually so each can have its own fill
      for (let i = 0; i < coloredDots.length; i++) {
        const dot = coloredDots[i]
        ctx.fillStyle = dot.baseColor
        ctx.beginPath()
        ctx.arc(dot.x, dot.y, dot.r, 0, Math.PI * 2)
        ctx.fill()
      }

      // Keep animating if:
      // - pointer is moving OR
      // - shimmerTime is advancing OR
      // - waves still exist
      const moving = Math.abs(displayX - mouseX) > 0.05 || Math.abs(displayY - mouseY) > 0.05
      const hasWaves = waves.length > 0

      if (moving || hasWaves || hasPointer) {
        requestAnimationFrame(draw)
      } else {
        // stop loop until something moves/clicks again
        isAnimating = false
      }
    }

    // Kick off first frame
    ensureAnimating()

    // cleanup on unmount
    return () => {
      window.removeEventListener("resize", handleResize)
      window.removeEventListener("mousemove", handleMouseMove)
      window.removeEventListener("touchmove", handleTouchMove)
      window.removeEventListener("click", handleClick)
      window.removeEventListener("touchstart", handleTouchStart)
      if (resizeTimer) clearTimeout(resizeTimer)
    }
  }, [])

  // This canvas is the visual background layer.
  // We DO want pointer interactivity (mousemove, click),
  // BUT we are listening on window, so we can leave pointer-events:none here
  // so it doesn't block button clicks in your UI.
  return <canvas ref={canvasRef} className="w-full h-full" aria-hidden="true" />
}
