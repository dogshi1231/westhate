"use client"

import { useState, useEffect } from "react"
import { X } from "lucide-react"

interface VariantOption {
  duration: string
  name: string
  description: string
  price: string
  badge?: "POPULAR" | "BEST VALUE"
}

interface VariantModalProps {
  isOpen: boolean
  onClose: () => void
  productName: string
  variants: VariantOption[]
  onSelectVariant: (variant: VariantOption) => void
  readyForEmbed?: boolean
}

export function VariantModal({
  isOpen,
  onClose,
  productName,
  variants,
  onSelectVariant,
  readyForEmbed = false,
}: VariantModalProps) {
  const [selectedVariant, setSelectedVariant] = useState<string | null>(null)
  const [showEmbedContainer, setShowEmbedContainer] = useState(false)

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = ""
      setSelectedVariant(null)
      setShowEmbedContainer(false)
    }

    return () => {
      document.body.style.overflow = ""
    }
  }, [isOpen])

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen) {
        onClose()
      }
    }

    document.addEventListener("keydown", handleEscape)
    return () => document.removeEventListener("keydown", handleEscape)
  }, [isOpen, onClose])

  const handleVariantClick = (variant: VariantOption) => {
    setSelectedVariant(variant.duration)

    setTimeout(() => {
      if (readyForEmbed) {
        // Show embed container instead of closing
        setShowEmbedContainer(true)
      } else {
        onSelectVariant(variant)
        onClose()
      }
    }, 500)
  }

  if (!isOpen) return null

  return (
    <div className="variant-modal" onClick={onClose}>
      <div className="variant-modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="variant-modal-header">
          <h3 className="variant-modal-title">
            {showEmbedContainer ? "Ready for Checkout" : `Select Duration - ${productName}`}
          </h3>
          <button className="variant-modal-close" onClick={onClose} aria-label="Close modal">
            <X className="close-icon" />
          </button>
        </div>

        <div className="variant-modal-body">
          {!showEmbedContainer ? (
            <>
              <p className="variant-modal-description">Choose your preferred subscription duration:</p>

              <div className="variant-options">
                {variants.map((variant) => (
                  <div
                    key={variant.duration}
                    className={`variant-option ${selectedVariant === variant.duration ? "selected" : ""}`}
                    onClick={() => handleVariantClick(variant)}
                    data-duration={variant.duration}
                  >
                    <div className="variant-info">
                      <span className="variant-name">{variant.name}</span>
                      <span className="variant-desc">{variant.description}</span>
                    </div>
                    <span className="variant-price">{variant.price}</span>
                    {variant.badge && (
                      <span className={`variant-badge ${variant.badge === "BEST VALUE" ? "premium" : ""}`}>
                        {variant.badge}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div id="embed-container" className="embed-ready w-full min-h-[400px] flex items-center justify-center">
              <div className="text-center p-8">
                <p className="text-white/60 mb-4">Embed ready for SellHub / SellAuth</p>
                <p className="text-white font-semibold">{productName}</p>
                <p className="text-white/40 text-sm mt-2">Insert your embed code here</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
