import { Header } from "@/components/header"
import { Shield, AlertCircle, RefreshCw } from "lucide-react"

export default function CallOfDutyStatusPage() {
  const products = [
    { name: "Zenith", price: "From €20.00", updated: "Updated 2h ago", status: "Undetected", statusLevel: "safe" },
    { name: "Sol EXTERNAL", price: "From €24.99", updated: "Updated 2h ago", status: "Undetected", statusLevel: "safe" },
    { name: "Verse Perm Spoofer", price: "From €19.99", updated: "Updated 4h ago", status: "Undetected", statusLevel: "safe" },
    { name: "Temp", price: "From €29.99", updated: "Updated 1h ago", status: "Undetected", statusLevel: "safe" },
    { name: "Phone Verified Steam Accounts", price: "Instant Delivery", updated: "Updated Now", status: "Available", statusLevel: "safe" },
  ]

  function getStatusStyles(level: string) {
    if (level === "safe") {
      return {
        pillClass:
          "bg-[rgba(0,128,0,0.15)] text-emerald-300 border border-emerald-500/40 shadow-[0_0_9px_rgba(16,185,129,0.6)]",
        dotClass: "bg-emerald-400 shadow-[0_0_7px_rgba(16,185,129,0.8)]",
        rowOuterGlow:
          "0 0 14px rgba(0,255,128,0.25), 0 0 35px rgba(0,255,128,0.15), inset 0 0 9px rgba(0,255,128,0.15)",
        rowBorderColor: "border-emerald-500/40",
      }
    }
    if (level === "updating") {
      return {
        pillClass:
          "bg-[rgba(255,200,0,0.12)] text-amber-300 border border-amber-400/40 shadow-[0_0_9px_rgba(251,191,36,0.5)]",
        dotClass: "bg-amber-400 shadow-[0_0_7px_rgba(251,191,36,0.8)]",
        rowOuterGlow:
          "0 0 14px rgba(251,191,36,0.25), 0 0 35px rgba(251,191,36,0.15), inset 0 0 9px rgba(251,191,36,0.15)",
        rowBorderColor: "border-amber-400/40",
      }
    }
    return {
      pillClass:
        "bg-[rgba(255,0,0,0.12)] text-red-300 border border-red-500/40 shadow-[0_0_9px_rgba(239,68,68,0.5)]",
      dotClass: "bg-red-400 shadow-[0_0_7px_rgba(239,68,68,0.8)]",
      rowOuterGlow:
        "0 0 14px rgba(239,68,68,0.25), 0 0 35px rgba(239,68,68,0.15), inset 0 0 9px rgba(239,68,68,0.15)",
      rowBorderColor: "border-red-500/40",
    }
  }

  return (
    <div className="min-h-screen bg-transparent relative">
      <Header />

      <main className="mx-auto px-7 lg:px-20 mt-24 relative z-20 max-w-[1400px]">
        {/* PAGE TITLE */}
        <section className="my-16">
          <h2 className="text-white text-[2.8rem] font-extrabold mb-2">
            Call of Duty - All Cheats Status
          </h2>

          <div className="mt-2 text-[13px] text-white/60 flex flex-wrap items-center gap-2 font-mono">
            <span className="flex items-center gap-1 text-xl font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(16,185,129,0.8)]" />
              Live sync active
            </span>
            <span className="text-white/30">•</span>
            <span className="text-lg font-bold">Last refreshed: 12:51 AM EST</span>
          </div>

          {/* OUTER PANEL */}
          <div
            className="
              mt-6 rounded-2xl border border-emerald-500/10
              bg-[rgba(15,15,15,0.9)]
              shadow-[0_0_30px_rgba(0,255,128,0.05)]
              backdrop-blur-[2px]
            "
          >
            {/* CATEGORY HEADER */}
            <div className="px-7 py-5 text-base text-white/70 border-b border-white/10 font-semibold">
              Call of Duty / Warzone
            </div>

            {/* PRODUCT ROWS */}
            <ul>
              {products.map((product, i) => {
                const styles = getStatusStyles(product.statusLevel)
                return (
                  <li
                    key={i}
                    className={`
                      flex flex-col sm:flex-row sm:items-center sm:justify-between gap-5
                      px-7 py-6
                      bg-[rgba(20,20,20,0.7)]
                      border ${styles.rowBorderColor}
                      rounded-xl
                      sm:mx-4 mt-4
                      transition-all duration-300 hover:scale-[1.01]
                    `}
                    style={{ boxShadow: styles.rowOuterGlow }}
                  >
                    {/* LEFT SIDE */}
                    <div className="flex items-start gap-5">
                      <div
                        className="
                          w-18 h-18 rounded-md
                          bg-gradient-to-br from-[#2a123a] to-[#000]
                          ring-1 ring-white/10
                          shadow-[0_0_22px_rgba(168,85,247,0.4)]
                          flex items-center justify-center text-[11px]
                          text-white/70 font-medium leading-tight
                        "
                      >
                        IMG
                      </div>

                      <div className="flex flex-col">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-white font-semibold text-[17px] leading-none">
                            {product.name}
                          </span>
                          <span className="text-[11px] font-medium px-2 py-[2px] rounded bg-white/10 text-white/50 uppercase tracking-widest">
                            COD
                          </span>
                        </div>

                        <div className="text-[14px] text-white/70 mt-1">
                          {product.price}
                        </div>
                        <div className="text-[12px] text-white/40 font-mono mt-1">
                          {product.updated}
                        </div>
                      </div>
                    </div>

                    {/* RIGHT SIDE */}
                    <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4 sm:ml-auto">
                      <div
                        className={`
                          flex items-center gap-2
                          text-[13px] font-semibold px-3.5 py-1.5 rounded-full
                          ${styles.pillClass}
                        `}
                      >
                        <span className={`w-1.5 h-1.5 rounded-full ${styles.dotClass}`} />
                        <span>{product.status}</span>
                      </div>

                      <button
                        className="
                          text-[13px] text-white/80
                          bg-[rgba(0,0,0,0.4)]
                          border border-white/10
                          rounded-md
                          px-5 py-2
                          hover:bg-white/5 hover:text-emerald-200
                          hover:border-emerald-400/40
                          transition-all
                        "
                      >
                        View Product
                      </button>
                    </div>
                  </li>
                )
              })}
            </ul>
          </div>
        </section>

        {/* STATUS LEGEND */}
        <section className="my-20">
          <h2 className="text-2xl font-bold text-white mb-6">
            Status Checker
          </h2>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-7">
            {/* Undetected */}
            <div className="bg-[#101010]/90 border border-emerald-600/40 rounded-xl shadow-[0_0_22px_rgba(16,185,129,0.3)] p-5 flex flex-row gap-4">
              <div className="flex items-center justify-center w-9 h-9 rounded-md bg-emerald-600 text-white shadow-[0_0_10px_rgba(16,185,129,0.6)] flex-shrink-0">
                <Shield className="h-4.5 w-4.5" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-white font-semibold text-base">Undetected</span>
                  <span className="text-[10px] font-semibold bg-emerald-500 text-white px-2 py-[2px] rounded-full">
                    Safe
                  </span>
                </div>
                <p className="text-[13px] text-white/70">
                  Our cheat is fully secure and safe to use. It&apos;s actively maintained and updated to stay undetected by anti-cheat systems.
                </p>
              </div>
            </div>

            {/* Under Development */}
            <div className="bg-[#101010]/90 border border-amber-500/40 rounded-xl shadow-[0_0_22px_rgba(251,191,36,0.3)] p-5 flex flex-row gap-4">
              <div className="flex items-center justify-center w-9 h-9 rounded-md bg-amber-500 text-black shadow-[0_0_10px_rgba(251,191,36,0.6)] flex-shrink-0">
                <RefreshCw className="h-4.5 w-4.5" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-white font-semibold text-base">Under Development</span>
                  <span className="text-[10px] font-semibold bg-amber-500 text-black px-2 py-[2px] rounded-full">
                    Updating
                  </span>
                </div>
                <p className="text-[13px] text-white/70">
                  Our team is currently updating the cheat to ensure compatibility with the latest game version and improved security.
                </p>
              </div>
            </div>

            {/* Detected */}
            <div className="bg-[#101010]/90 border border-red-500/40 rounded-xl shadow-[0_0_22px_rgba(239,68,68,0.4)] p-5 flex flex-row gap-4">
              <div className="flex items-center justify-center w-9 h-9 rounded-md bg-red-500 text-white shadow-[0_0_10px_rgba(239,68,68,0.6)] flex-shrink-0">
                <AlertCircle className="h-4.5 w-4.5" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-white font-semibold text-base">Detected</span>
                  <span className="text-[10px] font-semibold bg-red-500 text-white px-2 py-[2px] rounded-full">
                    Unsafe
                  </span>
                </div>
                <p className="text-[13px] text-white/70">
                  The cheat is currently detected by anti-cheat systems and unsafe to use. Please wait for our team to provide an updated version.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}
