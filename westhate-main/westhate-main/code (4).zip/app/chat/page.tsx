import { Header } from "@/components/header"
import { MessageSquare, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function ChatPage() {
  return (
    <div className="min-h-screen bg-[#0a0a0d] text-white">
      <Header />

      <main className="max-w-[800px] mx-auto px-5 md:px-8 py-20 pt-[120px]">
        <div className="bg-[#0f1016] rounded-2xl p-8 md:p-12 border border-white/10 shadow-2xl">
          <div className="flex flex-col items-center text-center gap-6">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center">
              <MessageSquare className="w-10 h-10" />
            </div>

            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-3">Join Our Discord Community</h1>
              <p className="text-gray-400 text-lg">
                Connect with our team and community members for support, updates, and discussions.
              </p>
            </div>

            <div className="w-full max-w-md space-y-4 mt-4">
              <div className="bg-white/5 rounded-xl p-6 border border-white/10">
                <h3 className="font-semibold mb-2 flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                  What you'll get:
                </h3>
                <ul className="text-sm text-gray-400 space-y-2 ml-4">
                  <li>• 24/7 Community Support</li>
                  <li>• Product Updates & Announcements</li>
                  <li>• Direct Access to Our Team</li>
                  <li>• Exclusive Deals & Giveaways</li>
                </ul>
              </div>

              <Button
                asChild
                size="lg"
                className="w-full bg-[#5865F2] hover:bg-[#4752C4] text-white font-bold text-lg py-6 h-auto rounded-xl shadow-lg hover:scale-105 transition-transform"
              >
                <a
                  href="https://discord.gg/your-invite-link"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2"
                >
                  Join Discord Server
                  <ExternalLink className="w-5 h-5" />
                </a>
              </Button>

              <p className="text-xs text-gray-500 text-center">
                By joining, you agree to follow our community guidelines and Discord's Terms of Service.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
