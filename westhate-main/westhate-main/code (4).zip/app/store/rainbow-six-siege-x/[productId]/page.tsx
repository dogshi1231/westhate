"use client"

import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { CheckCircle2, Shield, CreditCard, Headphones, Check } from "lucide-react"
import Link from "next/link"
import { useState } from "react"

const relatedProducts = [
  {
    id: "r6-esp",
    name: "ESP & Wallhack",
    priceRange: "$19.99 - $49.99",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    id: "r6-no-recoil",
    name: "No Recoil",
    priceRange: "$14.99 - $34.99",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    id: "r6-triggerbot",
    name: "Triggerbot",
    priceRange: "$12.99 - $29.99",
    image: "/placeholder.svg?height=300&width=400",
  },
]

const feedback = [
  {
    user: "SiegeChampion",
    comment: "Undetected and works great!",
    time: "3 hours ago",
  },
  {
    user: "DiamondPlayer",
    comment: "Customer service is top-notch.",
    time: "6 hours ago",
  },
  {
    user: "TacticalGamer",
    comment: "Been using for months, no issues at all.",
    time: "2 days ago",
  },
]

export default function ProductDetailPage({ params }: { params: { productId: string } }) {
  const [selectedVariant, setSelectedVariant] = useState<"day" | "week" | "month">("day")

  const variants = {
    day: { label: "Day", price: 18.99 },
    week: { label: "Week", price: 44.99 },
    month: { label: "Month", price: 69.99, originalPrice: 79.99 },
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <Header />
      <main className="max-w-[1200px] mx-auto px-5 md:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* LEFT COLUMN */}
          <div className="lg:col-span-2 space-y-8">
            {/* Video Area */}
            <div className="bg-[#0f1016] rounded-2xl overflow-hidden shadow-lg">
              <div className="aspect-video bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
                <div className="text-center">
                  <div className="w-20 h-20 mx-auto mb-4 bg-white/10 rounded-full flex items-center justify-center">
                    <svg className="w-10 h-10" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M8 5v14l11-7z" />
                    </svg>
                  </div>
                  <p className="text-gray-400">Video Preview</p>
                </div>
              </div>
            </div>

            {/* More Like This */}
            <div>
              <h2 className="text-2xl font-bold mb-6">More like this</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {relatedProducts.map((product) => (
                  <Link
                    key={product.id}
                    href={`/store/rainbow-six-siege-x/${product.id}`}
                    className="group block bg-[#0f1016] rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl hover:-translate-y-0.5 hover:bg-[#151828] transition-all duration-200"
                  >
                    <div className="relative aspect-[3/4]">
                      <img
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        className="w-full h-full object-cover"
                      />
                      <div
                        className="absolute bottom-0 left-0 right-0 p-3"
                        style={{
                          background: "linear-gradient(to top, #1a1c25 85%, transparent)",
                        }}
                      >
                        <p className="text-sm font-bold mb-0.5">{product.priceRange}</p>
                        <p className="text-xs text-gray-300">{product.name}</p>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>

          {/* RIGHT COLUMN */}
          <div className="space-y-6">
            {/* Purchase Panel */}
            <div className="bg-[#0f1016] rounded-2xl p-6 shadow-lg border border-white/5">
              <div className="mb-6">
                <h3 className="text-xl font-bold mb-1">Aimbot</h3>
                <p className="text-sm text-gray-400">Premium Cheat</p>
              </div>

              {/* Variant Selector */}
              <div className="mb-6">
                <h4 className="text-sm font-medium mb-3">Variant</h4>
                <div className="space-y-2">
                  {Object.entries(variants).map(([key, variant]) => (
                    <button
                      key={key}
                      onClick={() => setSelectedVariant(key as "day" | "week" | "month")}
                      className={`w-full flex items-center justify-between p-3 rounded-lg border transition-all ${
                        selectedVariant === key
                          ? "border-white/30 bg-white/5"
                          : "border-white/10 bg-transparent hover:border-white/20"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                            selectedVariant === key ? "border-yellow-500" : "border-white/30"
                          }`}
                        >
                          {selectedVariant === key && <Check className="w-3 h-3 text-yellow-500" />}
                        </div>
                        <span className="text-sm font-medium">{variant.label}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {variant.originalPrice && (
                          <span className="text-xs text-gray-500 line-through">
                            ${variant.originalPrice.toFixed(2)}
                          </span>
                        )}
                        <span className="text-sm font-bold">${variant.price.toFixed(2)}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <Button
                asChild
                className="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-bold py-6 text-lg mb-6"
              >
                <a href="#">Buy Now - ${variants[selectedVariant].price.toFixed(2)}</a>
              </Button>

              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <Shield className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium">Money-back guarantee</p>
                    <p className="text-sm text-gray-400">30-day refund policy</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CreditCard className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium">Secure checkout</p>
                    <p className="text-sm text-gray-400">Crypto & card accepted</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Headphones className="w-5 h-5 text-purple-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium">24/7 support</p>
                    <p className="text-sm text-gray-400">Always here to help</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium">Instant delivery</p>
                    <p className="text-sm text-gray-400">Access immediately</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Recent Feedback */}
            <div className="bg-[#0f1016] rounded-2xl p-6 shadow-lg border border-white/5">
              <h3 className="text-lg font-bold mb-4">Recent feedback</h3>
              <div className="space-y-4">
                {feedback.map((item, index) => (
                  <div key={index} className="flex gap-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-yellow-500 to-orange-500 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium text-sm">{item.user}</p>
                        <span className="text-xs text-gray-500">{item.time}</span>
                      </div>
                      <p className="text-sm text-gray-300">{item.comment}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
