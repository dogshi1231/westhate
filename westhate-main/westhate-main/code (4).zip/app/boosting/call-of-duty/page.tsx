import { Header } from "@/components/header"

export default function CallOfDutyBoostingPage() {
  return (
    <div className="min-h-screen bg-[#0a0d14] text-white">
      <Header />

      <main className="pt-[72px] px-6 py-12 max-w-7xl mx-auto">
        <h1 className="text-4xl font-bold mb-8">Call of Duty Boosting</h1>
        <p className="text-gray-400">Boosting services for Call of Duty will be available soon.</p>
      </main>
    </div>
  )
}
