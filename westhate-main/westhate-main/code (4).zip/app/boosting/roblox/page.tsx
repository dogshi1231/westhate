import { Header } from "@/components/header"

export default function RobloxBoostingPage() {
  return (
    <div className="min-h-screen bg-[#0a0d14] text-white">
      <Header />

      <main className="pt-[72px] px-6 py-12 max-w-7xl mx-auto">
        <h1 className="text-4xl font-bold mb-8">Roblox Boosting</h1>
        <p className="text-gray-400">Boosting services for Roblox will be available soon.</p>
      </main>
    </div>
  )
}
